import { adminSetPlan, isSuperAdmin, requireJwt, requireSystemAdmin } from "../_shared/privileged_gateway.ts";
import { logAdminAction, logSystemAction } from "../_shared/audit_logger.ts";
import { safeErrorResponse, validationErrorResponse } from "../_shared/errors.ts";
import { checkRateLimit, corsHeaders } from "../_shared/rate_limit.ts";
import { extractClientIp } from "../_shared/security.ts";

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return jsonResponse({ error: "Method not allowed" }, 405);

  const authHeader = req.headers.get("Authorization");
  const ipAddress = extractClientIp(req.headers.get("x-forwarded-for"));
  const userAgent = req.headers.get("user-agent") ?? "unknown";

  try {
    if (!authHeader?.startsWith("Bearer ")) {
      await logSystemAction({
        actionType: "auth:login_attempt",
        actionDescription: "Admin set-plan blocked due to missing token",
        ipAddress,
        userAgent,
        metadata: { endpoint: "admin-set-plan", status: "failed" },
      });
      return jsonResponse({ error: "Unauthorized" }, 401);
    }

    const { userId: actorUserId } = await requireJwt(authHeader);
    const callerIsSuperAdmin = await isSuperAdmin(actorUserId);
    if (!callerIsSuperAdmin) {
      const rate = await checkRateLimit(ipAddress, "general", { perMin: 10, perHour: 100 });
      if (!rate.allowed) {
        await logSystemAction({
          actionType: "security:rate_limit",
          actionDescription: "Rate limit exceeded for admin-set-plan",
          ipAddress,
          userAgent,
        });
        return jsonResponse({ error: "Too many requests" }, 429);
      }
    }

    await requireSystemAdmin(authHeader);

    const { workspace_id, new_plan, reason, target_user_id } = await req.json();
    if (!workspace_id || !new_plan || !reason) {
      return validationErrorResponse("workspace_id, new_plan, and reason are required", corsHeaders);
    }

    const result = await adminSetPlan({
      authHeader,
      workspaceId: workspace_id,
      newPlan: new_plan,
      reason,
      targetUserId: target_user_id ?? null,
      ipAddress,
      userAgent,
    });

    await logAdminAction({
      actorUserId,
      targetUserId: target_user_id ?? null,
      workspaceId: workspace_id,
      actionType: "admin:plan:set:api",
      actionDescription: "Admin plan override request completed",
      ipAddress,
      userAgent,
      metadata: { new_plan, reason },
    });

    return jsonResponse(result);
  } catch (err) {
    if (err instanceof Error && err.message === "Forbidden") {
      try {
        const { userId } = await requireJwt(authHeader);
        await logAdminAction({
          actorUserId: userId,
          actionType: "security:admin_access_denied",
          actionDescription: "Non-system-admin attempted admin-set-plan",
          ipAddress,
          userAgent,
        });
      } catch {
        // Ignore nested failures.
      }
      return jsonResponse({ error: "Forbidden" }, 403);
    }

    if (err instanceof Error && err.message === "Unauthorized") {
      await logSystemAction({
        actionType: "auth:login_attempt",
        actionDescription: "Admin set-plan blocked due to invalid token",
        ipAddress,
        userAgent,
        metadata: { endpoint: "admin-set-plan", status: "failed" },
      });
      return jsonResponse({ error: "Unauthorized" }, 401);
    }

    return safeErrorResponse(err, "[admin-set-plan]", corsHeaders);
  }
});

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  graphql_public: {
    Tables: {
      [_ in never]: never
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      graphql: {
        Args: {
          extensions?: Json
          operationName?: string
          query?: string
          variables?: Json
        }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
  public: {
    Tables: {
      admin_audit_log: {
        Row: {
          action: string
          admin_user_id: string
          created_at: string
          details: Json | null
          id: string
          target_user_id: string | null
        }
        Insert: {
          action: string
          admin_user_id: string
          created_at?: string
          details?: Json | null
          id?: string
          target_user_id?: string | null
        }
        Update: {
          action?: string
          admin_user_id?: string
          created_at?: string
          details?: Json | null
          id?: string
          target_user_id?: string | null
        }
        Relationships: []
      }
      campaign_activity: {
        Row: {
          action: string
          campaign_id: string
          created_at: string
          details: Json
          id: string
          user_id: string
        }
        Insert: {
          action: string
          campaign_id: string
          created_at?: string
          details?: Json
          id?: string
          user_id: string
        }
        Update: {
          action?: string
          campaign_id?: string
          created_at?: string
          details?: Json
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "campaign_activity_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
        ]
      }
      campaigns: {
        Row: {
          budget: number | null
          created_at: string
          description: string | null
          end_date: string | null
          id: string
          name: string
          start_date: string | null
          status: Database["public"]["Enums"]["campaign_status"]
          updated_at: string
          workspace_id: string
        }
        Insert: {
          budget?: number | null
          created_at?: string
          description?: string | null
          end_date?: string | null
          id?: string
          name: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["campaign_status"]
          updated_at?: string
          workspace_id: string
        }
        Update: {
          budget?: number | null
          created_at?: string
          description?: string | null
          end_date?: string | null
          id?: string
          name?: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["campaign_status"]
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "campaigns_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      credits_usage: {
        Row: {
          action_type: string
          amount: number
          created_at: string
          id: string
          reference_id: string | null
          workspace_id: string
        }
        Insert: {
          action_type: string
          amount: number
          created_at?: string
          id?: string
          reference_id?: string | null
          workspace_id: string
        }
        Update: {
          action_type?: string
          amount?: number
          created_at?: string
          id?: string
          reference_id?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "credits_usage_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      email_templates: {
        Row: {
          body: string
          created_at: string
          id: string
          name: string
          subject: string
          updated_at: string
          workspace_id: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          name: string
          subject: string
          updated_at?: string
          workspace_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          name?: string
          subject?: string
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "email_templates_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      enrichment_jobs: {
        Row: {
          attempts: number
          created_at: string
          failure_reason: string | null
          id: string
          idempotency_key: string
          platform: string
          status: Database["public"]["Enums"]["enrichment_status"]
          updated_at: string
          username: string
          workspace_id: string
        }
        Insert: {
          attempts?: number
          created_at?: string
          failure_reason?: string | null
          id?: string
          idempotency_key: string
          platform: string
          status?: Database["public"]["Enums"]["enrichment_status"]
          updated_at?: string
          username: string
          workspace_id: string
        }
        Update: {
          attempts?: number
          created_at?: string
          failure_reason?: string | null
          id?: string
          idempotency_key?: string
          platform?: string
          status?: Database["public"]["Enums"]["enrichment_status"]
          updated_at?: string
          username?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "enrichment_jobs_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      follower_history: {
        Row: {
          created_at: string
          follower_count: number
          id: string
          profile_id: string
          recorded_at: string
        }
        Insert: {
          created_at?: string
          follower_count: number
          id?: string
          profile_id: string
          recorded_at?: string
        }
        Update: {
          created_at?: string
          follower_count?: number
          id?: string
          profile_id?: string
          recorded_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "follower_history_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "influencer_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      influencer_evaluations: {
        Row: {
          evaluated_at: string
          evaluation: Json
          id: string
          overall_score: number
          platform: string
          username: string
          workspace_id: string
        }
        Insert: {
          evaluated_at?: string
          evaluation?: Json
          id?: string
          overall_score?: number
          platform: string
          username: string
          workspace_id: string
        }
        Update: {
          evaluated_at?: string
          evaluation?: Json
          id?: string
          overall_score?: number
          platform?: string
          username?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "influencer_evaluations_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      influencer_lists: {
        Row: {
          created_at: string
          id: string
          name: string
          updated_at: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          updated_at?: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "influencer_lists_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      influencer_posts: {
        Row: {
          caption: string | null
          comments: number | null
          created_at: string
          id: string
          image_urls: string[] | null
          is_sponsored: boolean | null
          likes: number | null
          platform_post_id: string
          posted_at: string
          profile_id: string
        }
        Insert: {
          caption?: string | null
          comments?: number | null
          created_at?: string
          id?: string
          image_urls?: string[] | null
          is_sponsored?: boolean | null
          likes?: number | null
          platform_post_id: string
          posted_at: string
          profile_id: string
        }
        Update: {
          caption?: string | null
          comments?: number | null
          created_at?: string
          id?: string
          image_urls?: string[] | null
          is_sponsored?: boolean | null
          likes?: number | null
          platform_post_id?: string
          posted_at?: string
          profile_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "influencer_posts_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "influencer_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      influencer_profiles: {
        Row: {
          audience_quality_score: number | null
          avatar_url: string | null
          bio: string | null
          bot_probability: number | null
          city: string | null
          created_at: string
          data_source: string | null
          engagement_rate: number | null
          enriched_at: string | null
          enrichment_error: string | null
          enrichment_status: string | null
          follower_count: number | null
          following_count: number | null
          fraud_score: number | null
          full_name: string | null
          id: string
          metrics: Json | null
          overall_score: number | null
          platform: string
          posts_count: number | null
          primary_niche: string | null
          secondary_niches: string[] | null
          username: string
        }
        Insert: {
          audience_quality_score?: number | null
          avatar_url?: string | null
          bio?: string | null
          bot_probability?: number | null
          city?: string | null
          created_at?: string
          data_source?: string | null
          engagement_rate?: number | null
          enriched_at?: string | null
          enrichment_error?: string | null
          enrichment_status?: string | null
          follower_count?: number | null
          following_count?: number | null
          fraud_score?: number | null
          full_name?: string | null
          id?: string
          metrics?: Json | null
          overall_score?: number | null
          platform: string
          posts_count?: number | null
          primary_niche?: string | null
          secondary_niches?: string[] | null
          username: string
        }
        Update: {
          audience_quality_score?: number | null
          avatar_url?: string | null
          bio?: string | null
          bot_probability?: number | null
          city?: string | null
          created_at?: string
          data_source?: string | null
          engagement_rate?: number | null
          enriched_at?: string | null
          enrichment_error?: string | null
          enrichment_status?: string | null
          follower_count?: number | null
          following_count?: number | null
          fraud_score?: number | null
          full_name?: string | null
          id?: string
          metrics?: Json | null
          overall_score?: number | null
          platform?: string
          posts_count?: number | null
          primary_niche?: string | null
          secondary_niches?: string[] | null
          username?: string
        }
        Relationships: []
      }
      influencers_cache: {
        Row: {
          city_extracted: string | null
          created_at: string
          data: Json
          embedding: string | null
          enriched_at: string | null
          id: string
          platform: string
          ttl_expires_at: string | null
          updated_at: string
          username: string
        }
        Insert: {
          city_extracted?: string | null
          created_at?: string
          data?: Json
          embedding?: string | null
          enriched_at?: string | null
          id?: string
          platform: string
          ttl_expires_at?: string | null
          updated_at?: string
          username: string
        }
        Update: {
          city_extracted?: string | null
          created_at?: string
          data?: Json
          embedding?: string | null
          enriched_at?: string | null
          id?: string
          platform?: string
          ttl_expires_at?: string | null
          updated_at?: string
          username?: string
        }
        Relationships: []
      }
      invoices: {
        Row: {
          amount_paid: number | null
          created_at: string
          currency: string | null
          id: string
          invoice_pdf: string | null
          status: string | null
          stripe_invoice_id: string | null
          workspace_id: string
        }
        Insert: {
          amount_paid?: number | null
          created_at?: string
          currency?: string | null
          id?: string
          invoice_pdf?: string | null
          status?: string | null
          stripe_invoice_id?: string | null
          workspace_id: string
        }
        Update: {
          amount_paid?: number | null
          created_at?: string
          currency?: string | null
          id?: string
          invoice_pdf?: string | null
          status?: string | null
          stripe_invoice_id?: string | null
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoices_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      linked_accounts: {
        Row: {
          confidence_score: number
          created_at: string
          id: string
          matched_by: string
          platform_a: string
          platform_b: string
          profile_id_a: string
          profile_id_b: string | null
          username_a: string
          username_b: string
        }
        Insert: {
          confidence_score?: number
          created_at?: string
          id?: string
          matched_by?: string
          platform_a: string
          platform_b: string
          profile_id_a: string
          profile_id_b?: string | null
          username_a: string
          username_b: string
        }
        Update: {
          confidence_score?: number
          created_at?: string
          id?: string
          matched_by?: string
          platform_a?: string
          platform_b?: string
          profile_id_a?: string
          profile_id_b?: string | null
          username_a?: string
          username_b?: string
        }
        Relationships: []
      }
      list_items: {
        Row: {
          created_at: string
          data: Json
          id: string
          list_id: string
          notes: string | null
          platform: string
          username: string
        }
        Insert: {
          created_at?: string
          data?: Json
          id?: string
          list_id: string
          notes?: string | null
          platform: string
          username: string
        }
        Update: {
          created_at?: string
          data?: Json
          id?: string
          list_id?: string
          notes?: string | null
          platform?: string
          username?: string
        }
        Relationships: [
          {
            foreignKeyName: "list_items_list_id_fkey"
            columns: ["list_id"]
            isOneToOne: false
            referencedRelation: "influencer_lists"
            referencedColumns: ["id"]
          },
        ]
      }
      outreach_log: {
        Row: {
          campaign_id: string
          card_id: string
          clicked_at: string | null
          contacted_at: string
          email_subject: string | null
          email_to: string | null
          id: string
          method: string
          notes: string | null
          opened_at: string | null
          platform: string
          status: string
          unsubscribed: boolean | null
          username: string
        }
        Insert: {
          campaign_id: string
          card_id: string
          clicked_at?: string | null
          contacted_at?: string
          email_subject?: string | null
          email_to?: string | null
          id?: string
          method?: string
          notes?: string | null
          opened_at?: string | null
          platform: string
          status?: string
          unsubscribed?: boolean | null
          username: string
        }
        Update: {
          campaign_id?: string
          card_id?: string
          clicked_at?: string | null
          contacted_at?: string
          email_subject?: string | null
          email_to?: string | null
          id?: string
          method?: string
          notes?: string | null
          opened_at?: string | null
          platform?: string
          status?: string
          unsubscribed?: boolean | null
          username?: string
        }
        Relationships: [
          {
            foreignKeyName: "outreach_log_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "outreach_log_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: false
            referencedRelation: "pipeline_cards"
            referencedColumns: ["id"]
          },
        ]
      }
      pipeline_cards: {
        Row: {
          agreed_rate: number | null
          campaign_id: string
          created_at: string
          data: Json
          id: string
          notes: string | null
          platform: string
          position: number
          stage_id: string
          updated_at: string
          username: string
        }
        Insert: {
          agreed_rate?: number | null
          campaign_id: string
          created_at?: string
          data?: Json
          id?: string
          notes?: string | null
          platform: string
          position?: number
          stage_id: string
          updated_at?: string
          username: string
        }
        Update: {
          agreed_rate?: number | null
          campaign_id?: string
          created_at?: string
          data?: Json
          id?: string
          notes?: string | null
          platform?: string
          position?: number
          stage_id?: string
          updated_at?: string
          username?: string
        }
        Relationships: [
          {
            foreignKeyName: "pipeline_cards_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pipeline_cards_stage_id_fkey"
            columns: ["stage_id"]
            isOneToOne: false
            referencedRelation: "pipeline_stages"
            referencedColumns: ["id"]
          },
        ]
      }
      pipeline_stages: {
        Row: {
          campaign_id: string
          color: string
          created_at: string
          id: string
          name: string
          position: number
        }
        Insert: {
          campaign_id: string
          color?: string
          created_at?: string
          id?: string
          name: string
          position?: number
        }
        Update: {
          campaign_id?: string
          color?: string
          created_at?: string
          id?: string
          name?: string
          position?: number
        }
        Relationships: [
          {
            foreignKeyName: "pipeline_stages_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          consent_given_at: string | null
          created_at: string
          full_name: string | null
          id: string
          onboarding_completed: boolean
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          consent_given_at?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          onboarding_completed?: boolean
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          consent_given_at?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          onboarding_completed?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      saved_searches: {
        Row: {
          created_at: string
          filters: Json
          id: string
          name: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          filters?: Json
          id?: string
          name: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          filters?: Json
          id?: string
          name?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "saved_searches_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      search_history: {
        Row: {
          created_at: string
          filters: Json
          id: string
          location: string | null
          platform: string
          query: string
          result_count: number
          workspace_id: string
        }
        Insert: {
          created_at?: string
          filters?: Json
          id?: string
          location?: string | null
          platform: string
          query: string
          result_count?: number
          workspace_id: string
        }
        Update: {
          created_at?: string
          filters?: Json
          id?: string
          location?: string | null
          platform?: string
          query?: string
          result_count?: number
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "search_history_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      subscriptions: {
        Row: {
          cancel_at_period_end: boolean | null
          created_at: string
          current_period_end: string | null
          current_period_start: string | null
          id: string
          plan: string
          status: string
          stripe_customer_id: string
          stripe_subscription_id: string | null
          updated_at: string
          workspace_id: string
        }
        Insert: {
          cancel_at_period_end?: boolean | null
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string | null
          id?: string
          plan?: string
          status?: string
          stripe_customer_id: string
          stripe_subscription_id?: string | null
          updated_at?: string
          workspace_id: string
        }
        Update: {
          cancel_at_period_end?: boolean | null
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string | null
          id?: string
          plan?: string
          status?: string
          stripe_customer_id?: string
          stripe_subscription_id?: string | null
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: true
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      tracking_events: {
        Row: {
          created_at: string
          id: string
          ip_address: string | null
          link_id: string
          referrer: string | null
          user_agent: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          ip_address?: string | null
          link_id: string
          referrer?: string | null
          user_agent?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          ip_address?: string | null
          link_id?: string
          referrer?: string | null
          user_agent?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tracking_events_link_id_fkey"
            columns: ["link_id"]
            isOneToOne: false
            referencedRelation: "tracking_links"
            referencedColumns: ["id"]
          },
        ]
      }
      tracking_links: {
        Row: {
          campaign_id: string | null
          click_count: number
          created_at: string
          id: string
          original_url: string
          short_code: string
          workspace_id: string
        }
        Insert: {
          campaign_id?: string | null
          click_count?: number
          created_at?: string
          id?: string
          original_url: string
          short_code: string
          workspace_id: string
        }
        Update: {
          campaign_id?: string | null
          click_count?: number
          created_at?: string
          id?: string
          original_url?: string
          short_code?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tracking_links_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tracking_links_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      workspace_members: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["workspace_role"]
          user_id: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["workspace_role"]
          user_id: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["workspace_role"]
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workspace_members_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      workspace_secrets: {
        Row: {
          created_at: string
          encrypted_api_key: string | null
          hubspot_api_key: string | null
          updated_at: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          encrypted_api_key?: string | null
          hubspot_api_key?: string | null
          updated_at?: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          encrypted_api_key?: string | null
          hubspot_api_key?: string | null
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workspace_secrets_workspace_id_fkey"
            columns: ["workspace_id"]
            isOneToOne: true
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      workspaces: {
        Row: {
          ai_credits_remaining: number
          created_at: string
          credits_reset_at: string
          email_sends_remaining: number
          enrichment_credits_remaining: number
          id: string
          name: string
          owner_id: string
          plan: string
          search_credits_remaining: number
          settings: Json
        }
        Insert: {
          ai_credits_remaining?: number
          created_at?: string
          credits_reset_at?: string
          email_sends_remaining?: number
          enrichment_credits_remaining?: number
          id?: string
          name: string
          owner_id: string
          plan?: string
          search_credits_remaining?: number
          settings?: Json
        }
        Update: {
          ai_credits_remaining?: number
          created_at?: string
          credits_reset_at?: string
          email_sends_remaining?: number
          enrichment_credits_remaining?: number
          id?: string
          name?: string
          owner_id?: string
          plan?: string
          search_credits_remaining?: number
          settings?: Json
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      consume_enrichment_credit: { Args: { ws_id: string }; Returns: undefined }
      consume_search_credit: { Args: { ws_id: string }; Returns: undefined }
      get_user_workspace: {
        Args: never
        Returns: {
          role: string
          workspace_id: string
        }[]
      }
      get_user_workspace_id: { Args: never; Returns: string }
      get_workspace_secret: { Args: { ws_id: string }; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
      is_super_admin: { Args: never; Returns: boolean }
      is_workspace_member:
        | {
            Args: { _user_id: string; _workspace_id: string }
            Returns: boolean
          }
        | { Args: { _workspace_id: string }; Returns: boolean }
      is_workspace_owner: { Args: { _workspace_id: string }; Returns: boolean }
      set_workspace_secret: {
        Args: { secret_val: string; ws_id: string }
        Returns: undefined
      }
      update_workspace_settings: {
        Args: { _name?: string; _settings?: Json; _workspace_id: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "user" | "super_admin" | "support" | "viewer"
      audit_action:
        | "create"
        | "update"
        | "delete"
        | "login"
        | "logout"
        | "export"
        | "impersonate"
        | "credit_adjustment"
      campaign_status: "draft" | "active" | "completed" | "archived"
      credit_action: "search" | "enrichment" | "export" | "deep_enrichment"
      email_confidence: "high" | "medium" | "low" | "none"
      enrichment_status:
        | "pending"
        | "processing"
        | "completed"
        | "failed"
        | "dead_letter"
      influencer_status:
        | "new"
        | "contacted"
        | "negotiating"
        | "booked"
        | "passed"
      platform_type: "instagram" | "tiktok" | "youtube"
      subscription_status:
        | "active"
        | "canceled"
        | "past_due"
        | "trialing"
        | "paused"
      subscription_tier: "free" | "basic" | "pro" | "agency" | "enterprise"
      trust_tier: "clean" | "suspicious" | "high_risk" | "unverified"
      workspace_role: "owner" | "admin" | "member"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  graphql_public: {
    Enums: {},
  },
  public: {
    Enums: {
      app_role: ["admin", "user", "super_admin", "support", "viewer"],
      audit_action: [
        "create",
        "update",
        "delete",
        "login",
        "logout",
        "export",
        "impersonate",
        "credit_adjustment",
      ],
      campaign_status: ["draft", "active", "completed", "archived"],
      credit_action: ["search", "enrichment", "export", "deep_enrichment"],
      email_confidence: ["high", "medium", "low", "none"],
      enrichment_status: [
        "pending",
        "processing",
        "completed",
        "failed",
        "dead_letter",
      ],
      influencer_status: [
        "new",
        "contacted",
        "negotiating",
        "booked",
        "passed",
      ],
      platform_type: ["instagram", "tiktok", "youtube"],
      subscription_status: [
        "active",
        "canceled",
        "past_due",
        "trialing",
        "paused",
      ],
      subscription_tier: ["free", "basic", "pro", "agency", "enterprise"],
      trust_tier: ["clean", "suspicious", "high_risk", "unverified"],
      workspace_role: ["owner", "admin", "member"],
    },
  },
} as const

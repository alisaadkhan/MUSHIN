/**
 * CookiePolicyPage.tsx  —  MUSHIN  ·  Complete Rewrite
 *
 * Replaces the 48-line InfluenceIQ-branded stub.
 * Full Cookie Policy with cookie table and MUSHIN design system.
 */

import React from 'react';
import LegalPageLayout, { LegalSection } from '@/components/LegalPageLayout';

/* ─── Cookie Table Component ─────────────────────────────────────────────── */
const CookieTable = ({
  rows,
}: {
  rows: { name: string; type: string; purpose: string; duration: string }[];
}) => (
  <div className="overflow-x-auto rounded-xl border border-white/[0.07] mt-4">
    <table className="w-full text-xs min-w-[500px]">
      <thead>
        <tr className="border-b border-white/[0.07] bg-white/[0.02]">
          {['Cookie Name', 'Type', 'Purpose', 'Duration'].map((h) => (
            <th key={h} className="text-left py-3 px-4 text-zinc-500 font-semibold">
              {h}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row, i) => (
          <tr
            key={row.name}
            className={`border-b border-white/[0.04] last:border-0 ${i % 2 === 1 ? 'bg-white/[0.01]' : ''}`}
          >
            <td className="py-3 px-4 font-mono text-purple-300/80">{row.name}</td>
            <td className="py-3 px-4 text-zinc-400">{row.type}</td>
            <td className="py-3 px-4 text-zinc-400">{row.purpose}</td>
            <td className="py-3 px-4 text-zinc-500">{row.duration}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

const sections: LegalSection[] = [
  {
    id: 'what-are-cookies',
    title: '1. What Are Cookies',
    content: (
      <>
        <p>
          Cookies are small text files placed on your device when you visit MUSHIN. They allow
          the platform to remember your preferences, maintain your login session, and understand
          how you use the service so we can improve it.
        </p>
        <p>
          We use only first-party cookies — cookies set by MUSHIN directly. We do not use
          third-party advertising cookies or tracking pixels from advertising networks.
        </p>
      </>
    ),
  },
  {
    id: 'cookies-we-use',
    title: '2. Cookies We Use',
    content: (
      <>
        <p>
          We use three categories of cookies. Essential cookies cannot be disabled as they are
          required for the platform to function. Analytics and preference cookies can be managed
          through your browser settings.
        </p>

        <div className="mt-6 space-y-6">
          {/* Essential */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 rounded-full bg-green-400" />
              <span className="text-white font-semibold text-sm">Essential Cookies</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-green-400/10 text-green-400 border border-green-400/20 font-bold uppercase tracking-wider">
                Required
              </span>
            </div>
            <p className="text-zinc-500 text-xs mb-3">
              Necessary for authentication, security, and core platform functionality. Cannot be
              disabled.
            </p>
            <CookieTable
              rows={[
                {
                  name: 'sb-access-token',
                  type: 'Essential',
                  purpose: 'Supabase authentication session token',
                  duration: 'Session',
                },
                {
                  name: 'sb-refresh-token',
                  type: 'Essential',
                  purpose: 'Refresh access token without re-login',
                  duration: '7 days',
                },
                {
                  name: '__mushin_csrf',
                  type: 'Essential',
                  purpose: 'Cross-site request forgery protection',
                  duration: 'Session',
                },
              ]}
            />
          </div>

          {/* Analytics */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 rounded-full bg-blue-400" />
              <span className="text-white font-semibold text-sm">Analytics Cookies</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-400/10 text-blue-400 border border-blue-400/20 font-bold uppercase tracking-wider">
                Optional
              </span>
            </div>
            <p className="text-zinc-500 text-xs mb-3">
              Help us understand which features are used most, where users drop off, and how to
              improve the platform. All data is anonymised.
            </p>
            <CookieTable
              rows={[
                {
                  name: '__mushin_anon',
                  type: 'Analytics',
                  purpose: 'Anonymous session identifier for usage analytics',
                  duration: '1 year',
                },
                {
                  name: '__mushin_lp',
                  type: 'Analytics',
                  purpose: 'Last page visited for funnel analysis',
                  duration: '30 days',
                },
              ]}
            />
          </div>

          {/* Preference */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 rounded-full bg-purple-400" />
              <span className="text-white font-semibold text-sm">Preference Cookies</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-400/10 text-purple-400 border border-purple-400/20 font-bold uppercase tracking-wider">
                Optional
              </span>
            </div>
            <p className="text-zinc-500 text-xs mb-3">
              Remember your settings and display preferences so you don't have to re-configure
              them each visit.
            </p>
            <CookieTable
              rows={[
                {
                  name: '__mushin_sidebar',
                  type: 'Preference',
                  purpose: 'Sidebar collapsed/expanded state',
                  duration: '1 year',
                },
                {
                  name: '__mushin_theme',
                  type: 'Preference',
                  purpose: 'UI theme preference (dark/light)',
                  duration: '1 year',
                },
                {
                  name: '__mushin_currency',
                  type: 'Preference',
                  purpose: 'Selected currency for pricing display',
                  duration: '1 year',
                },
              ]}
            />
          </div>
        </div>
      </>
    ),
  },
  {
    id: 'managing-cookies',
    title: '3. Managing Cookies',
    content: (
      <>
        <p>
          You can control and delete cookies through your browser settings. Here are links to
          cookie management guides for major browsers:
        </p>
        <ul className="list-none space-y-2 mt-3">
          {[
            { name: 'Google Chrome', url: 'https://support.google.com/chrome/answer/95647' },
            { name: 'Mozilla Firefox', url: 'https://support.mozilla.org/en-US/kb/cookies-information-websites-store-on-your-computer' },
            { name: 'Apple Safari', url: 'https://support.apple.com/guide/safari/manage-cookies-sfri11471/mac' },
            { name: 'Microsoft Edge', url: 'https://support.microsoft.com/en-us/windows/manage-cookies-in-microsoft-edge' },
          ].map(({ name }) => (
            <li key={name} className="flex items-start gap-2">
              <span className="mt-1 w-1.5 h-1.5 rounded-full bg-purple-500 flex-shrink-0" />
              <span className="text-purple-400">{name}</span>
            </li>
          ))}
        </ul>
        <p className="mt-4">
          Note: Disabling essential cookies will prevent you from logging in or using core
          platform features. Disabling analytics and preference cookies will not affect core
          functionality.
        </p>
      </>
    ),
  },
  {
    id: 'third-party',
    title: '4. Third-Party Services',
    content: (
      <>
        <p>
          MUSHIN uses the following third-party services that may set their own cookies or use
          similar storage mechanisms:
        </p>
        <ul className="list-none space-y-2 mt-3">
          {[
            {
              name: 'Stripe',
              purpose: 'Payment processing — Stripe may set cookies during the checkout flow',
            },
            {
              name: 'Supabase',
              purpose:
                'Authentication infrastructure — session tokens are stored in httpOnly cookies',
            },
          ].map(({ name, purpose }) => (
            <li key={name} className="flex items-start gap-2">
              <span className="mt-1 w-1.5 h-1.5 rounded-full bg-purple-500 flex-shrink-0" />
              <span>
                <strong className="text-white/80">{name}:</strong> {purpose}
              </span>
            </li>
          ))}
        </ul>
        <p className="mt-4">
          We do not use Google Analytics, Facebook Pixel, LinkedIn Insight Tag, or any
          advertising network cookies. No cross-site tracking is performed.
        </p>
      </>
    ),
  },
  {
    id: 'updates',
    title: '5. Policy Updates',
    content: (
      <p>
        We may update this Cookie Policy periodically. When we make material changes, we will
        update the "Last updated" date and notify active users by email. For questions, contact{' '}
        <span className="text-purple-400">privacy@mushin.com</span>.
      </p>
    ),
  },
];

export default function CookiePolicyPage() {
  return (
    <LegalPageLayout
      badge="Legal"
      title="Cookie Policy"
      subtitle="A transparent breakdown of every cookie MUSHIN uses — what it's called, why it exists, and how long it lives."
      lastUpdated="April 2026"
      sections={sections}
    />
  );
}

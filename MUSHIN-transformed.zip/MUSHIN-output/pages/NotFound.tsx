/**
 * NotFound.tsx  —  MUSHIN  ·  Complete Rewrite
 *
 * Replaces the 20-line stub that referenced `AuroraBackground` and `aurora-text`
 * CSS classes from the old design system (which don't exist in the MUSHIN system).
 *
 * Changes vs. original:
 *  - Removed AuroraBackground component dependency (broken import)
 *  - Removed `aurora-text` CSS class (not in MUSHIN system)
 *  - Self-contained: all visual effects inline, zero external deps beyond MushInIcon
 *  - Matches MUSHIN dark system: #060608, purple accent, Syne font
 *  - Added navigation options beyond just "Return Home"
 *  - Added subtle animated background consistent with landing page
 *  - Accessible: proper heading hierarchy, aria-labels
 */

import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Search, Home, MessageSquare } from 'lucide-react';
import { MushInIcon } from '@/components/ui/MushInLogo';

/* ─── Subtle Dot Grid Background ─────────────────────────────────────────── */
const DotGrid = () => (
  <div
    className="pointer-events-none absolute inset-0"
    style={{
      backgroundImage: 'radial-gradient(circle, rgba(168,85,247,0.18) 1px, transparent 1px)',
      backgroundSize: '32px 32px',
      maskImage: 'radial-gradient(ellipse 60% 60% at 50% 50%, black 40%, transparent 100%)',
      WebkitMaskImage: 'radial-gradient(ellipse 60% 60% at 50% 50%, black 40%, transparent 100%)',
    }}
  />
);

/* ─── Quick Links ─────────────────────────────────────────────────────────── */
const quickLinks = [
  { to: '/', icon: Home, label: 'Home', desc: 'Back to the landing page' },
  { to: '/search', icon: Search, label: 'Search Creators', desc: 'Find Pakistani influencers' },
  { to: '/support', icon: MessageSquare, label: 'Support', desc: 'Get help from our team' },
];

/* ─── Main ────────────────────────────────────────────────────────────────── */
export default function NotFound() {
  return (
    <div
      className="min-h-screen bg-[#060608] text-white flex flex-col relative overflow-hidden"
      style={{ fontFamily: "'Syne', sans-serif" }}
    >
      {/* Background */}
      <div
        className="pointer-events-none fixed inset-0"
        style={{
          background:
            'radial-gradient(ellipse 55% 45% at 50% 40%, rgba(88,28,135,0.12) 0%, transparent 70%)',
        }}
      />
      <DotGrid />

      {/* Nav */}
      <nav className="relative z-10 border-b border-white/[0.06] py-4 px-6">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-zinc-500 hover:text-white transition-colors"
          aria-label="Back to home"
        >
          <MushInIcon size={22} />
          <span className="font-bold tracking-[0.15em] text-sm">MUSHIN</span>
        </Link>
      </nav>

      {/* Main content */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 py-20 text-center">
        {/* 404 display */}
        <div
          className="font-black leading-none mb-6 select-none"
          style={{
            fontSize: 'clamp(6rem, 20vw, 14rem)',
            background: 'linear-gradient(135deg, rgba(168,85,247,0.15) 0%, rgba(88,28,135,0.05) 100%)',
            WebkitBackgroundClip: 'text',
            backgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            filter: 'drop-shadow(0 0 60px rgba(168,85,247,0.15))',
          }}
          aria-hidden="true"
        >
          404
        </div>

        {/* Heading */}
        <h1 className="text-2xl md:text-3xl font-black tracking-tight mb-3 text-white">
          Page Not Found
        </h1>
        <p className="text-zinc-400 text-base max-w-sm mx-auto mb-10 leading-relaxed">
          This page doesn't exist — even MUSHIN's intelligence couldn't locate it.
        </p>

        {/* Primary CTA */}
        <Link
          to="/"
          className="inline-flex items-center gap-2.5 bg-purple-600 hover:bg-purple-500 transition-colors text-white font-bold text-sm px-8 py-3.5 rounded-full mb-12"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to Home
        </Link>

        {/* Quick Links */}
        <div className="w-full max-w-md">
          <p className="text-zinc-600 text-xs uppercase tracking-widest font-bold mb-4">
            Or go somewhere helpful
          </p>
          <div className="grid gap-2">
            {quickLinks.map(({ to, icon: Icon, label, desc }) => (
              <Link
                key={to}
                to={to}
                className="flex items-center gap-4 px-5 py-4 rounded-xl border border-white/[0.07] bg-white/[0.02] hover:border-purple-500/25 hover:bg-white/[0.04] transition-all duration-150 text-left group"
              >
                <div className="w-9 h-9 rounded-lg bg-white/[0.04] border border-white/[0.07] flex items-center justify-center flex-shrink-0 group-hover:border-purple-500/30 transition-colors">
                  <Icon className="w-4 h-4 text-zinc-500 group-hover:text-purple-400 transition-colors" />
                </div>
                <div>
                  <div className="text-sm font-bold text-white/80 group-hover:text-white transition-colors">
                    {label}
                  </div>
                  <div className="text-xs text-zinc-600">{desc}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 py-6 text-center">
        <p className="text-zinc-700 text-xs">
          &copy; 2026 Mushin. Made in Pakistan.
        </p>
      </footer>
    </div>
  );
}

/**
 * TermsPage.tsx  —  MUSHIN  ·  Complete Rewrite
 *
 * Replaces the 50-line InfluenceIQ-branded stub.
 * Full Terms of Service with 10 structured sections.
 * Uses shared LegalPageLayout with MUSHIN design system.
 */

import React from 'react';
import LegalPageLayout, { LegalSection } from '@/components/LegalPageLayout';

const sections: LegalSection[] = [
  {
    id: 'acceptance',
    title: '1. Acceptance of Terms',
    content: (
      <>
        <p>
          By accessing or using the MUSHIN platform ("Service"), you agree to be bound by these
          Terms of Service ("Terms") and our Privacy Policy. If you do not agree to these Terms,
          you may not access or use the Service.
        </p>
        <p>
          These Terms apply to all users of the Service, including users who are also contributors
          of content, information, and other materials or services to the platform.
        </p>
      </>
    ),
  },
  {
    id: 'description',
    title: '2. Service Description',
    content: (
      <>
        <p>
          MUSHIN is Pakistan's AI-powered influencer intelligence platform. The Service provides
          creator discovery, fraud detection, campaign management, and analytics tools designed
          for marketing agencies and brands operating in the Pakistani market.
        </p>
        <p>
          Features and capabilities vary by subscription plan. We reserve the right to modify,
          add, or remove features at any time with reasonable notice to active subscribers.
        </p>
      </>
    ),
  },
  {
    id: 'accounts',
    title: '3. Accounts & Registration',
    content: (
      <>
        <p>
          To use the Service, you must create an account with accurate information. You are
          responsible for maintaining the confidentiality of your credentials and for all activity
          that occurs under your account.
        </p>
        <p>
          You must be at least 18 years of age to create an account. By creating an account, you
          represent and warrant that you meet this requirement and that the information you provide
          is accurate and complete.
        </p>
        <p>
          You agree to notify us immediately at{' '}
          <span className="text-purple-400">support@mushin.com</span> if you become aware of any
          unauthorised access to your account.
        </p>
      </>
    ),
  },
  {
    id: 'acceptable-use',
    title: '4. Acceptable Use',
    content: (
      <>
        <p>You agree not to use the Service to:</p>
        <ul className="list-none space-y-2 mt-2">
          {[
            'Violate any applicable law or regulation',
            'Harvest or scrape creator data at scale for competing products',
            'Harass, defame, or harm creators or other users',
            'Submit false, misleading, or fraudulent information',
            'Attempt to reverse-engineer or circumvent the platform's security',
            'Access the Service through automated means beyond authorised API usage',
            'Resell or sublicense access to the Service without prior written consent',
          ].map((item) => (
            <li key={item} className="flex items-start gap-2">
              <span className="mt-1 w-1.5 h-1.5 rounded-full bg-red-500/70 flex-shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
        <p className="mt-4">
          Violation of acceptable use policies may result in immediate suspension or termination
          of your account without refund.
        </p>
      </>
    ),
  },
  {
    id: 'payment',
    title: '5. Payment & Billing',
    content: (
      <>
        <p>
          Paid plans are billed in advance on a monthly or annual basis in Pakistani Rupees (PKR).
          All prices are inclusive of applicable taxes unless stated otherwise.
        </p>
        <p>
          Payments are processed securely by Stripe. We do not store your card information on our
          servers. By providing payment information, you authorise us to charge you for the
          applicable subscription.
        </p>
        <p>
          If a payment fails, we will attempt to re-process the charge three times over seven
          days. If payment remains unsuccessful, your account will be downgraded to the Free plan
          and access to paid features will be suspended.
        </p>
      </>
    ),
  },
  {
    id: 'cancellation',
    title: '6. Cancellation & Refunds',
    content: (
      <>
        <p>
          You may cancel your subscription at any time from your account dashboard. Cancellation
          takes effect at the end of the current billing period — you retain full access until
          then.
        </p>
        <p>
          We offer a 14-day money-back guarantee on first-time purchases of paid plans. To
          request a refund, email <span className="text-purple-400">billing@mushin.com</span>{' '}
          within 14 days of the original charge. Refunds are processed within 5–10 business days.
        </p>
        <p>
          We do not provide pro-rated refunds for partial billing periods beyond the 14-day
          guarantee window.
        </p>
      </>
    ),
  },
  {
    id: 'data-accuracy',
    title: '7. Data Accuracy Disclaimer',
    content: (
      <>
        <p>
          MUSHIN's creator data, fraud scores, engagement metrics, and ROAS estimates are
          generated using AI models and publicly available signals. These are estimates and
          projections — not guarantees of campaign performance.
        </p>
        <p>
          You acknowledge that influencer marketing outcomes depend on many factors outside our
          control, and that MUSHIN's intelligence tools are decision-support aids, not
          deterministic predictions. We are not liable for campaign outcomes based on MUSHIN data.
        </p>
      </>
    ),
  },
  {
    id: 'intellectual-property',
    title: '8. Intellectual Property',
    content: (
      <>
        <p>
          The MUSHIN platform, including its design, algorithms, brand, and all associated
          content, is owned by Mushin Pvt Ltd and protected by Pakistani and international
          intellectual property laws.
        </p>
        <p>
          You retain ownership of any content or data you upload to the platform. By uploading
          content, you grant us a limited, non-exclusive licence to use it solely to provide the
          Service to you.
        </p>
        <p>
          You may not copy, distribute, modify, or create derivative works from the MUSHIN
          platform without our prior written permission.
        </p>
      </>
    ),
  },
  {
    id: 'limitation-of-liability',
    title: '9. Limitation of Liability',
    content: (
      <>
        <p>
          To the maximum extent permitted by applicable law, MUSHIN and its officers, directors,
          employees, and agents shall not be liable for any indirect, incidental, special,
          consequential, or punitive damages arising from your use of — or inability to use — the
          Service.
        </p>
        <p>
          Our total liability to you for any claim arising out of or related to these Terms or
          the Service shall not exceed the amount you paid to us in the 12 months preceding the
          claim.
        </p>
        <p>
          Some jurisdictions do not allow the exclusion of certain warranties or limitations of
          liability, so some of the above limitations may not apply to you.
        </p>
      </>
    ),
  },
  {
    id: 'governing-law',
    title: '10. Governing Law',
    content: (
      <>
        <p>
          These Terms are governed by and construed in accordance with the laws of Pakistan.
          Any disputes arising under these Terms shall be subject to the exclusive jurisdiction
          of the courts of Karachi, Pakistan.
        </p>
        <p>
          If any provision of these Terms is found to be unenforceable, the remaining provisions
          will continue in full force and effect. Our failure to enforce any provision does not
          constitute a waiver of our right to enforce it in the future.
        </p>
        <p>
          For questions about these Terms, contact us at{' '}
          <span className="text-purple-400">legal@mushin.com</span>.
        </p>
      </>
    ),
  },
];

export default function TermsPage() {
  return (
    <LegalPageLayout
      badge="Legal"
      title="Terms of Service"
      subtitle="Please read these terms carefully before using MUSHIN. They govern your access to and use of the platform."
      lastUpdated="April 2026"
      sections={sections}
    />
  );
}
